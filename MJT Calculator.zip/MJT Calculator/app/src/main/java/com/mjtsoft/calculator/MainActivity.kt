package com.mjtsoft.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.Exception
import kotlin.math.PI
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

tvRes.text=""
tvExp.text=""
  }

/*---------------------------- (Public Variables) ----------------------------*/
    var newOp = true
    var newDot = true
    var selOp = ""
    var opCount = 0

    var n1 = 0.0
    var n2 = 1.0
    var np = 1.0

    var eqClicked = false
    var afterEq = false
    var afterEqValueBool = false
    var sqrDone = true
    var firstRun = true
    var afterEqValue = 0.0

/*---------------------------- (Mathematical Operations) ----------------------------*/
    fun opClick(view: View) {
        newDot = true
        newOp = true
        val btn = view as Button

        try {

// To recall last result (Start)
            if (afterEq) {
                afterEqValueBool = true
                afterEq = false
                eqClicked = false
            }
            if (afterEqValueBool) {
                afterEqValue = tvRes.text.toString().toDouble()
                tvExp.text = afterEqValue.toString()
                tvRes.text = ""
                opCount++


                afterEqValueBool = false
            }
            afterEq = false
// To recall last result (End)

            var expText = tvExp.text[tvExp.length() - 1].toString()
            var expText2 = tvExp.text[tvExp.length() - 1].toString()

            when (btn.id) {


//*------- Start of buAdd -------*//
                R.id.buAdd -> {




                    selOp = "+"

                    when (tvExp.text[tvExp.length() - 1].toString()) {
                        "-" -> {
                            selOp = "+"
                            tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)
                            tvExp.append("+")
                        }
                        "*" -> {
                            selOp = "+"
                            tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)
                            tvExp.append("+")
                        }

                        "/" -> {
                            selOp = "+"
                            tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)
                            tvExp.append("+")
                        }

                    }
//= For Operation changes to + (End)
                }
//*------- End of buAdd -------*//


//*------- Start of buSubs -------*//
                R.id.buSubs -> {
                    selOp = "-"
                    when (tvExp.text[tvExp.length() - 1].toString()) {
                        "+" -> {
                            selOp = "-"
                            tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)
                            tvExp.append("-")

                        }

                        "*" -> {
                            selOp = "-"
                            tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)
                            tvExp.append("-")
                        }

                        "/" -> {
                            selOp = "-"
                            tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)
                            tvExp.append("-")
                        }

                    }
//= For Operation changes to - (End)


                }
//*------- End of buSubs -------*//


//*------- Start of buMult -------*//
                R.id.buMult -> {
                    selOp = "*"

//= For Operation changes to * (Start)
                    when (tvExp.text[tvExp.length() - 1].toString()) {
                        "-" -> {
                            selOp = "*"
                            tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)
                            tvExp.append("*")
                        }

                        "+" -> {
                            selOp = "*"
                            tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)
                            tvExp.append("*")
                        }

                        "/" -> {
                            selOp = "*"
                            tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)
                            tvExp.append("*")
                        }

                    }
//= For Operation changes to * (End)
                }
/*------- End of buMult -------*/

//---------------------------------------------------------------------------------------------

/*------- Start of buDiv -------*/
                R.id.buDiv -> {
                    selOp = "/"

//= For Operation changes to / (Start)
                    when (tvExp.text[tvExp.length() - 1].toString()) {
                        "-" -> {
                            selOp = "/"
                            tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)
                            tvExp.append("/")
                        }
                        "+" -> {
                            selOp = "/"
                            tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)
                            tvExp.append("/")
                        }

                        "*" -> {
                            selOp = "/"
                            tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)
                            tvExp.append("/")
                        }

                    }
//= For Operation changes to / (End)


                }
/*------- End of buDiv -------*/

            }


/*------------------------------------------------- (Mathematical Operations  -------------------------------------------------*/
            if ((selOp == "+") && newOp && (expText != "+" && expText != "-" && expText != "*" && expText != "/")) {
                tvExp.append("+")
                if (opCount == 0) {
                    n1 = tvRes.text.toString().toDouble()
                    tvRes.text = n1.toString()
                    opCount++

                    //
                } else {
                    n1 += tvRes.text.toString().toDouble()
                    tvRes.text = n1.toString()

                }
            }
            if ((selOp == "-") && newOp && (expText != "+" && expText != "-" && expText != "*" && expText != "/")) {
                tvExp.append("-")
                if (opCount == 0) {
                    n1 = tvRes.text.toString().toDouble()
                    tvRes.text = n1.toString()
                    opCount++
                } else {
                    n1 -= tvRes.text.toString().toDouble()
                    tvRes.text = n1.toString()

                }

            }
            if ((selOp == "*") && newOp && (expText != "+" && expText != "-" && expText != "*" && expText != "/")) {
                tvExp.append("*")
                if (opCount == 0) {
                    n1 = tvRes.text.toString().toDouble()
                    tvRes.text = n1.toString()
                    opCount++
                } else {
                    n1 *= tvRes.text.toString().toDouble()
                    tvRes.text = n1.toString()

                }

            }
            if ((selOp == "/") && newOp && (expText != "+" && expText != "-" && expText != "*" && expText != "/")) {
                tvExp.append("/")
                if (opCount == 0) {
                    n1 = tvRes.text.toString().toDouble()
                    tvRes.text = n1.toString()
                    opCount++
                } else {
                    n1 /= tvRes.text.toString().toDouble()
                    tvRes.text = n1.toString()

                }

            }
/*------------------------------------------------- (Mathematical Operations  -------------------------------------------------*/

        } catch (e: Exception) {
        }


    }

/*---------------------------- (Numbers Input) ----------------------------*/
    fun numClick(view: View) {

        var btn = view as Button
        sqrDone = true
        if (eqClicked && afterEq) {
            cClick(view)
            eqClicked = false
            afterEq = false
            afterEqValueBool = false
            newDot = true

        }
        if (newOp == true) {
            newOp = false
            tvRes.text = ""

        }
        when (btn.id) {

            R.id.bu0 -> {
                tvExp.append("0")
                tvRes.append("0")
            }

            R.id.bu1 -> {
                tvExp.append("1")
                tvRes.append("1")
            }

            R.id.bu2 -> {
                tvExp.append("2")
                tvRes.append("2")
            }

            R.id.bu3 -> {
                tvExp.append("3")
                tvRes.append("3")
            }

            R.id.bu4 -> {
                tvExp.append("4")
                tvRes.append("4")
            }

            R.id.bu5 -> {
                tvExp.append("5")
                tvRes.append("5")
            }

            R.id.bu6 -> {
                tvExp.append("6")
                tvRes.append("6")
            }

            R.id.bu7 -> {
                tvExp.append("7")
                tvRes.append("7")
            }

            R.id.bu8 -> {
                tvExp.append("8")
                tvRes.append("8")
            }

            R.id.bu9 -> {
                tvExp.append("9")
                tvRes.append("9")
            }


            R.id.buPI -> {
                if (!tvRes.text.contains(".")){
                    tvExp.append(PI.toString())}

                tvRes.text=PI.toString()

            }


        }


    }

/*---------------------------- (Backspace Button) ----------------------------*/
    fun backSpc(view: View) {

        newOp = true
        try {

            if (eqClicked) cClick(view)

            if (tvExp.text != "") {
                tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)
            }

            if (tvRes.text != "") {
                tvRes.text = tvRes.text.substring(0, tvRes.text.length - 1)

            }
        } catch (e: Exception) {

        }

    }

/*---------------------------- (Dot Adding Button) ----------------------------*/
    fun buDot(view: View) {
        if (newDot) {
            if (newOp) {
                if (tvRes.text == "") tvRes.append("0")
                newOp = false
            }

            if (!tvRes.text.contains(".")) {
                if (tvRes.text == "") tvRes.append("0")
                tvRes.append(".")
                tvExp.append(".")
            }

        }


    }

/*---------------------------- (Clear all Button) ----------------------------*/
    fun cClick(view: View) {
        tvExp.text = ""
        tvRes.text = ""
        newOp = true
        newDot = true
        n1 = 0.0
        n2 = 0.0
        np = 1.0
        opCount = 0
        eqClicked = false
        afterEq = false
        afterEqValueBool = false
        sqrDone = true
    }

/*---------------------------- (Equal '=' Button) ----------------------------*/
    fun eqClick(view: View) {
        try {

            if (eqClicked == false) {
//To append (=) to tvExp (Start)
                var expText = tvExp.text[tvExp.length() - 1].toString()
                if (expText == "+" || expText == "-" || expText == "*" || expText == "/") {

                    tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)
                    tvExp.append("=")
                    eqClicked = true
                    afterEq = true
                    afterEqValueBool = true

                }
                if (!newOp && opCount == 0 && tvRes.text != "" && firstRun) {
                    tvExp.append("=")
                    eqClicked = true
                    afterEq = true
                    afterEqValueBool = true
                    opClick(view = View(this))
                    firstRun = false
                }
//To append (=) to tvExp (Start)


                if ((selOp == "+") && !newOp && (expText != "+" && expText != "-" && expText != "*" && expText != "/")) {
                    tvExp.append("=")

                    if (opCount == 0) {
                        n1 = tvRes.text.toString().toDouble()
                        tvRes.text = n1.toString()
                        opCount++
                    } else {
                        n1 += tvRes.text.toString().toDouble()
                        tvRes.text = n1.toString()

                    }
                }

                if ((selOp == "-") && !newOp && (expText != "+" && expText != "-" && expText != "*" && expText != "/")) {
                    tvExp.append("=")
                    if (opCount == 0) {
                        n1 = tvRes.text.toString().toDouble()
                        tvRes.text = n1.toString()
                        opCount++
                    } else {
                        n1 -= tvRes.text.toString().toDouble()
                        tvRes.text = n1.toString()

                    }

                }

                if ((selOp == "*") && !newOp && (expText != "+" && expText != "-" && expText != "*" && expText != "/")) {
                    tvExp.append("=")
                    if (opCount == 0) {
                        n1 = tvRes.text.toString().toDouble()
                        tvRes.text = n1.toString()
                        opCount++
                    } else {
                        n1 *= tvRes.text.toString().toDouble()
                        tvRes.text = n1.toString()

                    }

                }

                if ((selOp == "/") && !newOp && (expText != "+" && expText != "-" && expText != "*" && expText != "/")) {
                    tvExp.append("=")
                    if (opCount == 0) {
                        n1 = tvRes.text.toString().toDouble()
                        tvRes.text = n1.toString()
                        opCount++
                    } else {
                        n1 /= tvRes.text.toString().toDouble()
                        tvRes.text = n1.toString()

                    }

                }


                eqClicked = true
                afterEq = true
                afterEqValueBool = true
                newDot = true
                newOp = true


            }
        } catch (E: Exception) {
        }
    }
    var tmpVal = 0.0

/*---------------------------- (Plus/Minus Button) ----------------------------*/
    fun p_mClick(view: View) {
        if (tvRes.text != "") {

            tmpVal = (tvRes.text.toString().toDouble()) * -1
            tvRes.text = tmpVal.toString()
        }
    }

/*---------------------------- (Percentage Button) ----------------------------*/
    var pertmp=0.0
    fun perClick(view: View) {
        try {
            pertmp= tvRes.text.toString().toDouble()/100

            if (eqClicked == false) {
//To append (=) to tvExp (Start)
                var expText = tvExp.text[tvExp.length() - 1].toString()
                if (expText == "+" || expText == "-" || expText == "*" || expText == "/") {

                    tvExp.text = tvExp.text.substring(0, tvExp.text.length - 1)

                    tvExp.append("%")
                    tvRes.text=pertmp.toString()
                    eqClicked = true
                    afterEq = true
                    afterEqValueBool = true

                }
                if (!newOp && opCount == 0 && tvRes.text != "" && firstRun) {
                    tvExp.append("%")
                    tvRes.text=pertmp.toString()
                    eqClicked = true
                    afterEq = true
                    afterEqValueBool = true
                    opClick(view = View(this))
                    firstRun = false
                }
//To append (=) to tvExp (Start)


                if ((selOp == "+") && !newOp && (expText != "+" && expText != "-" && expText != "*" && expText != "/")) {
                    tvExp.append("%")

                    if (opCount == 0) {
                        n1 = tvRes.text.toString().toDouble()/100
                        tvRes.text = n1.toString()
                        opCount++
                    } else {
                        n1 += tvRes.text.toString().toDouble()/100
                        tvRes.text = n1.toString()

                    }
                }

                if ((selOp == "-") && !newOp && (expText != "+" && expText != "-" && expText != "*" && expText != "/")) {
                    tvExp.append("%")
                    if (opCount == 0) {
                        n1 = tvRes.text.toString().toDouble()/100
                        tvRes.text = n1.toString()
                        opCount++
                    } else {
                        n1 -= tvRes.text.toString().toDouble()/100
                        tvRes.text = n1.toString()

                    }

                }

                if ((selOp == "*") && !newOp && (expText != "+" && expText != "-" && expText != "*" && expText != "/")) {
                    tvExp.append("%")
                    if (opCount == 0) {
                        n1 = tvRes.text.toString().toDouble()/100
                        tvRes.text = n1.toString()
                        opCount++
                    } else {
                        n1 *= tvRes.text.toString().toDouble()/100
                        tvRes.text = n1.toString()

                    }

                }

                if ((selOp == "/") && !newOp && (expText != "+" && expText != "-" && expText != "*" && expText != "/")) {
                    tvExp.append("")
                    if (opCount == 0) {
                        n1 = tvRes.text.toString().toDouble()/100
                        tvRes.text = n1.toString()
                        opCount++
                    } else {
                        n1 /= tvRes.text.toString().toDouble()/100
                        tvRes.text = n1.toString()

                    }

                }


                eqClicked = true
                afterEq = true
                afterEqValueBool = true
                newDot = true
                newOp = true


            }
        } catch (E: Exception) {

        }
    }

/*---------------------------- (Square Button) ----------------------------*/
    fun sqrClick(view: View) {
        try {
            if (sqrDone) {

                var tmp = tvRes.text.toString().toDouble()
                var sqrValue = sqrt(tmp)

                //?/cClick(view)
                tvExp.text = "√($tmp)="
                tvRes.text = sqrValue.toString()
                sqrDone = false
                afterEqValueBool = true
                afterEq = true
                newOp=true
                eqClicked=true


            }

        } catch (e: Exception) {

        }
    }

}























